import pygame

import time

pygame.init()

pygame.mixer.music.load("bleep_01.wav")

pygame.mixer.music.play()

time.sleep(5)
